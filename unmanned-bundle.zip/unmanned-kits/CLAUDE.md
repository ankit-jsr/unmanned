# CLAUDE.md (unmanned-kits)

Private repo for paid kits. The operating manual, chain of command and review gates are in
the public repo `unmanned/CLAUDE.md`; read it first. Two extra rules apply here:

1. Never copy anything from this repo into the public repo, an issue, a PR, or a post.
2. Never change this repo's visibility.
