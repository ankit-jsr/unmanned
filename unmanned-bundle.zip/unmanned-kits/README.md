# unmanned-kits (private)

Paid Claude skill kits sold by Unmanned. This repo must stay private: anything here that
became public would be free.

- One folder per kit under `kits/`, built with the `skill-eval` method from the public repo.
- A kit ships only when its pass rate is at least 90% on Claude and on the gate 3 model,
  and gates 2 and 3 pass.
- Buyers get kits through the payment platform, never through access to this repo.
- Strategy, decisions and the ledger live in the public repo `unmanned`.
