#!/usr/bin/env bash
# Creates and pushes both Unmanned repos, the needs-ankit label, the first two asks,
# and branch protection. Safe to re-run: existing repos are skipped.
#
# Before running:
#   1. Create a free GitHub organisation: https://github.com/account/organizations/new?plan=free
#   2. Install the GitHub CLI and log in: gh auth login
#
# Usage: ./bootstrap.sh [org-name]        (default: unmanned-hq)
set -euo pipefail

ORG="${1:-unmanned-hq}"
HERE="$(cd "$(dirname "$0")" && pwd)"

command -v git >/dev/null || { echo "git is not installed."; exit 1; }
command -v gh  >/dev/null || { echo "GitHub CLI is not installed: https://cli.github.com"; exit 1; }
gh auth status >/dev/null 2>&1 || { echo "Not logged in. Run: gh auth login"; exit 1; }
git config user.name >/dev/null || { echo "Set your git name: git config --global user.name \"Your Name\""; exit 1; }

if ! gh api "orgs/$ORG" --silent 2>/dev/null; then
  echo "Organisation '$ORG' not found or not accessible."
  echo "Create it (free plan): https://github.com/account/organizations/new?plan=free"
  echo "Then re-run: ./bootstrap.sh <the-org-name-you-chose>"
  exit 1
fi

if [ "$ORG" != "unmanned-hq" ]; then
  sed -i.bak "s#github.com/unmanned-hq/#github.com/$ORG/#g" "$HERE/unmanned/company/facts.csv"
  rm -f "$HERE/unmanned/company/facts.csv.bak"
fi

push_repo () {
  local dir="$1" name="$2" visibility="$3" desc="$4"
  if gh repo view "$ORG/$name" >/dev/null 2>&1; then
    echo "• $ORG/$name already exists, skipping."
    return
  fi
  cd "$HERE/$dir"
  if [ ! -d .git ]; then
    git init -q -b main
    git add -A
    git commit -q -m "Day 0: company bootstrapped by Claude (CEO)"
  fi
  gh repo create "$ORG/$name" "--$visibility" --source=. --remote=origin --push --description "$desc"
  echo "• Created $ORG/$name ($visibility)"
}

push_repo unmanned      unmanned      public  "A content-led business run in public by an AI. Claude is the CEO."
push_repo unmanned-kits unmanned-kits private "Paid Claude skill kits. Private."

REPO="$ORG/unmanned"

gh label create needs-ankit -R "$REPO" --color D93F0B \
  --description "An action only the investor can do: accounts, payments, publishing" --force >/dev/null
echo "• Label needs-ankit ready"

if [ -z "$(gh issue list -R "$REPO" --label needs-ankit --state all --limit 1 --json number -q '.[].number')" ]; then
  gh issue create -R "$REPO" --label needs-ankit \
    --title "Create the free Substack 'Unmanned'" \
    --body "**Action:** Create a free Substack named Unmanned. Do not connect Stripe.
**Why:** It's the email list kits are sold to, and the weekly build log.
**Time it takes:** 5 minutes.
**Where the result goes:** Tell Claude the Substack URL in the next Claude Code session." >/dev/null
  gh issue create -R "$REPO" --label needs-ankit \
    --title "Create the cross-model reviewer API key (gate 3)" \
    --body "**Action:** Create one API key from OpenAI or Google Gemini with a hard spend cap of ₹1,000/month. Copy \`.env.example\` to \`.env\` in your local clone and fill in REVIEWER_PROVIDER, REVIEWER_MODEL and REVIEWER_API_KEY.
**Why:** Gate 3. A second model family catches errors Claude would repeat.
**Time it takes:** 10 minutes.
**Where the result goes:** Only in your local \`.env\`. Never in an issue, chat or commit." >/dev/null
  echo "• Opened the first two needs-ankit issues"
fi

if gh api -X PUT "repos/$REPO/branches/main/protection" --input - >/dev/null 2>&1 <<'JSON'
{
  "required_status_checks": {
    "strict": false,
    "contexts": ["Gate 1a - secret scan", "Gate 1b - content checks"]
  },
  "enforce_admins": true,
  "required_pull_request_reviews": null,
  "restrictions": null
}
JSON
then
  echo "• main is protected: changes must pass CI"
else
  echo "! Could not set branch protection automatically. Claude will retry in the first session."
fi

cat <<NEXT

Done. Public repo: https://github.com/$REPO

Next:
  cd "$HERE/unmanned"
  claude

Then paste:
  You are the CEO of Unmanned. Read CLAUDE.md and follow the session-start protocol.
  Install the pre-commit hooks, run /review on content/log/001-i-killed-my-first-two-ideas.md,
  and start the vertical sprint in company/strategy.md.
NEXT
