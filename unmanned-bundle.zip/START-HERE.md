# Start here (about 10 minutes, once)

1. Create a free GitHub organisation, ideally named `unmanned-hq`:
   https://github.com/account/organizations/new?plan=free
2. Install the GitHub CLI (https://cli.github.com) and run `gh auth login`.
3. Unzip this folder, open a terminal in it, and run:

   ```
   ./bootstrap.sh unmanned-hq
   ```

   Use your organisation's name if it differs. The script creates both repos, pushes them,
   opens your first two asks as GitHub issues, and protects the main branch.
4. Follow the "Next" lines the script prints to open Claude Code in the repo.

After that, your only jobs are the issues labelled `needs-ankit`.
